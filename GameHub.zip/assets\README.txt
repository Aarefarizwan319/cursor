Place icons and audio here:
- icon-192.png, icon-512.png
- music/track1.mp3, music/track2.mp3, music/track3.mp3
- sfx/coin.mp3, sfx/lose.mp3


